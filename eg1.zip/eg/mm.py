from flask import Flask, render_template, request, redirect, url_for
from flask_mysqldb import MySQL

app = Flask(__name__)

# MySQL Configuration
app.config['MYSQL_HOST'] = 'localhost'
app.config['MYSQL_USER'] = 'root'
app.config['MYSQL_PASSWORD'] = 'devyani45'
app.config['MYSQL_DB'] = 'haca'

mysql = MySQL(app)

# Define routes
@app.route('/')
def index():
    # Render the starting page template
    return render_template('homepage.html')

@app.route('/questionnaire', methods=['GET', 'POST'])
def questionnaire():
    # Handle form submission for the questionnaire
    if request.method == 'POST':
        hair_type = request.form['hair_type']
        # You can process the form data here if needed
        # Then redirect to the index page
        return redirect(url_for('index'))

    # Render the questionnaire template
    return render_template('index.html', question="What's your hair type?")

@app.route('/shampoo-info', methods=['POST'])
def get_shampoo_info():
    # Assuming you are passing the hair type in the form data
    hair_type = request.form['hair_type']

    # Use the hair_type to fetch the relevant shampoo information from the database
    cur = mysql.connection.cursor()
    cur.execute('SELECT * FROM shampoo WHERE hair_type = %s', (hair_type,))
    shampoo_info = cur.fetchone()
    cur.close()

    if shampoo_info:
        return render_template('shampoo_info.html', hair_type=hair_type, shampoo_info=shampoo_info)
    else:
        return render_template('shampoo_info.html', hair_type=hair_type, shampoo_info=None)

if __name__ == '__main__':
    app.run(debug=True)
