from flask import Flask, render_template, request, redirect, url_for
from flask_mysqldb import MySQL
import random
from random import sample

app = Flask(__name__, static_folder='static')

# MySQL Configuration
app.config['MYSQL_HOST'] = 'localhost'
app.config['MYSQL_USER'] = 'root'
app.config['MYSQL_PASSWORD'] = 'devyani45'
app.config['MYSQL_DB'] = 'haircare'

mysql = MySQL(app)

# Define routes
@app.route('/')
def index():
    return render_template('homepage.html')
@app.route('/about')
def about():
    return render_template('about.html')

@app.route('/questionnaire', methods=['GET', 'POST'])
def questionnaire():
        if request.method == 'POST':
            hair_type = request.form['hair_type']
            return redirect(url_for('index'))
        return render_template('index.html', question="What's your hair type?")

@app.route('/shampoo-info', methods=['POST'])
def get_hair_info():
    
    hair_type = request.form['hair_type']

    
    cur = mysql.connection.cursor()

    
    cur.execute('SELECT s_id, s_brand, s_name, hair_type, sulphate_shampoo, paraben_shampoo, s_price, s_rating, image_name FROM shampoo WHERE hair_type = %s', (hair_type,))
    shampoo_info_list = cur.fetchall()

    
    cur.execute('SELECT c_id, c_name, c_brand,hair_type, c_price, c_rating, image_name FROM conditioner WHERE hair_type = %s', (hair_type,))
    conditioner_info_list = cur.fetchall()

    cur.execute('SELECT se_id, se_brand, se_name, hair_type, se_price, se_rating, image_name FROM serum WHERE hair_type = %s', (hair_type,))
    serums_info_list = cur.fetchall()

    cur.execute('SELECT o_id, o_brand, o_name, hair_type, o_price, o_rating, image_name FROM oil WHERE hair_type = %s', (hair_type,))
    oil_info_list = cur.fetchall()

    cur.execute('SELECT cr_id, cr_brand, cr_name, hair_type, cr_price, cr_rating, image_name FROM cream WHERE hair_type = %s', (hair_type,))
    cream_info_list = cur.fetchall()

    cur.execute('SELECT g_id, g_brand, g_name, hair_type, g_price, g_rating, image_name FROM gel WHERE hair_type = %s', (hair_type,))
    gel_info_list = cur.fetchall()
    
    cur.close()

    if shampoo_info_list or conditioner_info_list or serums_info_list or oil_info_list or cream_info_list or gel_info_list:
       
        random_shampoos = sample(shampoo_info_list, min(2, len(shampoo_info_list)))
        random_conditioners = sample(conditioner_info_list, min(2, len(conditioner_info_list)))
        random_serums = sample(serums_info_list, min(2, len(serums_info_list)))
        random_cream = sample(cream_info_list, min(2, len(cream_info_list)))
        random_oil = sample(oil_info_list, min(2, len(oil_info_list)))
        random_gel = sample(gel_info_list, min(2, len(gel_info_list)))
        return render_template('shampoo_info.html', hair_type=hair_type, shampoo_info_list=random_shampoos, conditioner_info_list=random_conditioners, serums_info_list=random_serums, oil_info_list=random_oil, cream_info_list=random_cream, gel_info_list=random_gel)
    else:
        return render_template('shampoo_info.html', hair_type=hair_type, shampoo_info_list=None, conditioner_info_list=None, serums_info_list=None, oil_info_list=None, cream_info_list=None, gel_info_list=None)

if __name__ == '__main__':
    app.run(debug=True)
