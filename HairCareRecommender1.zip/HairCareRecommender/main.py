from flask import Flask, render_template, request, redirect, url_for
from flask_mysqldb import MySQL
import random
from random import sample

app = Flask(__name__, static_folder='static')

# MySQL Configuration
app.config['MYSQL_HOST'] = 'localhost'
app.config['MYSQL_USER'] = 'root'
app.config['MYSQL_PASSWORD'] = 'devyani45'
app.config['MYSQL_DB'] = 'haca'

mysql = MySQL(app)

# Define routes
@app.route('/')
def index():
    # Render the starting page template
    return render_template('homepage.html')

@app.route('/questionnaire', methods=['GET', 'POST'])
def questionnaire():
    # Handle form submission for the questionnaire
    if request.method == 'POST':
        hair_type = request.form['hair_type']
        # You can process the form data here if needed
        # Then redirect to the index page
        return redirect(url_for('index'))

    # Render the questionnaire template
    return render_template('index.html', question="What's your hair type?")

@app.route('/shampoo-info', methods=['POST'])
def get_hair_info():
    # Assuming you are passing the hair type in the form data
    hair_type = request.form['hair_type']

    # Use the hair_type to fetch both shampoo and conditioner information from the database
    cur = mysql.connection.cursor()

    # Fetch shampoo info
    cur.execute('SELECT shampoo_id, brand, shampoo_name, hair_type, sulphate_shampoo, paraben_shampoo, price_s, rating, image_filename FROM shampoo WHERE hair_type = %s', (hair_type,))
    shampoo_info_list = cur.fetchall()

    # Fetch conditioner info
    cur.execute('SELECT conditioner_id, conditioner_name, hair_type, price, SilicateFree_or_Not, image_name FROM conditioner WHERE hair_type = %s', (hair_type,))
    conditioner_info_list = cur.fetchall()

    cur.execute('SELECT serums_id, brand_name, serum_name, hair_type, price_serum, rating, image_name FROM serums WHERE hair_type = %s', (hair_type,))
    serums_info_list = cur.fetchall()

    cur.execute('SELECT oil_id, brand_name, product_name, hair_type, price, rating, image_name FROM oil WHERE hair_type = %s', (hair_type,))
    oil_info_list = cur.fetchall()

    cur.execute('SELECT cream_id, brand_name, product_name, hair_type, price, rating, image_name FROM cream WHERE hair_type = %s', (hair_type,))
    cream_info_list = cur.fetchall()

    cur.execute('SELECT gel_id, brand_name, product_name, hair_type, price, rating, image_name FROM gel WHERE hair_type = %s', (hair_type,))
    gel_info_list = cur.fetchall()
    
    cur.close()

    if shampoo_info_list or conditioner_info_list or serums_info_list or oil_info_list or cream_info_list or gel_info_list:
        # Sample 2 random shampoos and 2 random conditioners
        random_shampoos = sample(shampoo_info_list, min(2, len(shampoo_info_list)))
        random_conditioners = sample(conditioner_info_list, min(2, len(conditioner_info_list)))
        random_serums = sample(serums_info_list, min(2, len(serums_info_list)))
        random_cream = sample(cream_info_list, min(2, len(cream_info_list)))
        random_oil = sample(oil_info_list, min(2, len(oil_info_list)))
        random_gel = sample(gel_info_list, min(2, len(gel_info_list)))
        return render_template('shampoo_info.html', hair_type=hair_type, shampoo_info_list=random_shampoos, conditioner_info_list=random_conditioners, serums_info_list=random_serums, oil_info_list=random_oil, cream_info_list=random_cream, gel_info_list=random_gel)
    else:
        return render_template('shampoo_info.html', hair_type=hair_type, shampoo_info_list=None, conditioner_info_list=None, serums_info_list=None, oil_info_list=None, cream_info_list=None, gel_info_list=None)

if __name__ == '__main__':
    app.run(debug=True)
